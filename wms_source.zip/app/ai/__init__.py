"""AI assistant support modules."""
