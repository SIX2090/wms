"""AI tool registry package."""
